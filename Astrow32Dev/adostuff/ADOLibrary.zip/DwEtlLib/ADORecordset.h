
//*****************************< ADORecordset.h >*****************************
//
//
//  Project.. : MFC ADO Related Tools                            
//  Author... : Tim Kohler                                                   
//  Date..... : 08/07/2002                                                    
//  Revision. : 00/00/0000                                                    
//  Library.. : DwEtlLib - Dynamic Link Library                             
//
//-----------------------------------------------------------------------------
//  Classes Defined 
//  ---------------
//
//  CADORecordset:  This class encapsulates the ADO Recordset interface.  The
//                  interface is designed to be reasonably similar to the ODBC
//                  MFC database class CRecordset.  The class supports dynamic
//                  binding as well as static binding.  
//
//
///   STATIC BINDING:
//                  To support static binding, a 'record' class must be created
//                  separately.  This record class must multiply inherit from CADORecordBinding
//                  and CADORecordset.  This closely approximates the interface of
//                  derived CRecordsets (except that the CRecordsets just define
//                  DoFieldExchange but here we implement CADORecordBinding).
//                  Here is a super simple example of one such class:
//
//       
//                  class CClientPlanRS : public CADORecordBinding, public CADORecordset
//                  {
//                      BEGIN_ADO_BINDING(CClientPlanRS)
//                      ADO_FIXED_LENGTH_ENTRY    (  1, adInteger, m_lClient_id, m_ulClient_idStatus, TRUE)
//                      ADO_VARIABLE_LENGTH_ENTRY2(  2, adVarChar, m_szClient_id_name, sizeof(m_szClient_id_name), m_ulClient_id_nameStatus, TRUE)
//                      ADO_VARIABLE_LENGTH_ENTRY2(  3, adVarChar, m_szClient_id_desc, sizeof(m_szClient_id_desc), m_ulClient_id_descStatus, TRUE)
//                      END_ADO_BINDING()
//
//                      //Attributes
//                      public:
//                      CClientPlanRS(CADODatabase* pDb = NULL, int nCacheSize = -1) : 
//                            CADORecordBinding(),
//                            CADORecordset(pDb, nCacheSize) 
//                         { SetRecordBinding(this); };
//
//                      LONG			m_lClient_id;
//                      ULONG			m_ulClient_idStatus;
//                      CHAR			m_szClient_id_name[51];
//                      ULONG			m_ulClient_id_nameStatus;
//                      CHAR			m_szClient_id_desc[51];
//                      ULONG			m_ulClient_id_descStatus;
//                   };
//
//
//
//       If you are familiar w/ the MFC class wizard you are already aware
//       of how nice it is when deriving a class from CRecordset (i.e. generating
//       the RFX and class data members that map to the table's columns).
//       Although there is no wizard integrated w/ developer studio to generate
//       the classes deriving from CADORecordBinding, a freeware wizard was 
//       found that takes all the work out of creating these classes.  It can be 
//       found at \\atl-d1-pdc-01\develop\tim\ADOWizard\ADORsWizard.exe.
//
//
//       Once the 'record' class has been created, just create a constructor as above 
//       call SetRecordBinding after calling the base class constructors.
//
//       Here are a couple of examples of using CADORecordset, CADODatabase, and
//       the above record statically bound recordset:
//
//
//       bOpen = db.Open("CLIMET", "TDK2", "NOONHIGH");
//
//       CClientPlanRS CliRs(&db);
//
//
//       //read table:
//       bRsOpen = CliRs.Open("select * from client_dim");
//   
//       while (!CliRs.IsEOF())
//       {
//         //do something w/ the records
//         CliRs.MoveNext();
//       }
//
//       //update the first existing row:
//       CliRs.MoveFirst();
//
//       strcpy(CliRs.m_szClient_id_name, "MOTOR999");      
//       BOOL bUpdate = CliRs.Update();
//
//       //add a new row:
//       CliRs.m_lClient_id = 999;
//       strcpy(CliRs.m_szClient_id_name, "SCHLUM");      
//       strcpy(CliRs.m_szClient_id_desc, "Schlumberger Inc");
//       BOOL bAdd = CliRs.AddNew();
//
//
//
//       DYNAMIC BINDING:
//             Static binding gives performance increases when the
//       layout of a query's response is known.  However, there are 
//       countless times when the desire may be to perform a 
//       strange query (i.e. calling an SQL function like COUNT, or
//       performing a join) where creating a static 'record' class
//       to bind is simply not worthwhile.  In addition there sometimes
//       arise cases where programs need to 'explore' a table's layout
//       and need to be able to query w/o knowing exactly what they'll
//       get in return (see ExtractBuilder and VcDef).  Dynamic binding
//       is excellent in these cases.  
//             CADORecordset (in conjunction with the _variant_t class)
//       provides an interface similar to that of CRecordset and CDbVariant.
//       In particular the GetRecordCount and GetFieldCount methods are
//       well suited for determining the basic shape (often used to determine
//       loop boundaries) of a query's result.  
//             Calling the GetFieldValue(int nIndex, _variant_t& vtValue)
//       method of the recordset will return the data in a single field w/in
//       a single record.  The type (vtValue.vt) tells where to look in the
//       union for the field's data. 
//             
//             In addition Dynamic binding may be used when a query's
//       response is known.  This is the typical way VB code uses ADO
//       with its queries.  Here is an example of executing a query 
//       and retrieving the results in this fashion:
//
//       // use the jet to read, we know the layout each record so we call the getfieldvalues w/
//       // the pre-known datatypes for the columns.	
//       CADODatabase db;
//
//       BOOL bOpen = db.Open("s:\\tim\\climet.mdb", "Admin", "", "Microsoft.Jet.OLEDB.3.51");
//       CADORecordset rs(&db);   
//
//       BOOL bRsOpen = rs.Open("select * from client_dim");
//
//       int nRows = rs.GetRecordCount();
//
//       int nKey;
//       CString strCliNm, strCliDesc;
//
//       BOOL fok = TRUE;
//
//       fok = rs.GetFieldValue(0, nKey);
//       fok = rs.GetFieldValue(1, strCliNm);
//       fok = rs.GetFieldValue(2, strCliDesc);
//   
//       db.Close();
//
//
//  For more detailed information on ADO and numerous C++ examples, please 
//  browse the following websites:
//
//   http://codeguru.earthweb.com/mfc_database/Ado_Aok.shtml
//   http://msdn.microsoft.com/library/default.asp?url=/library/en-us/ado270/htm/mdmthaddnewxvc.asp
//   http://www.codeproject.com/database/#ADO
//
//*****************************************************************************

// ADORecordset.h: interface for the CADORecordset class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADORECORDSET_H__2A47DE61_A977_11D6_9A62_00D0B7E45CC5__INCLUDED_)
#define AFX_ADORECORDSET_H__2A47DE61_A977_11D6_9A62_00D0B7E45CC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning(disable:4146)
#import "c:\program files\common files\system\ado\msado15.dll" named_guids rename("EOF", "bEOF") rename("BOF", "bBOF")
#pragma warning(default:4146)
using namespace ADODB;  

#include <icrsint.h> 

_COM_SMARTPTR_TYPEDEF(IADORecordBinding, __uuidof(IADORecordBinding));

class CADODatabase;

class AFX_EXT_CLASS CADORecordset   
{
public:
   enum Actions
   {
      doMoveFirst,
      doMoveLast,
      doMoveNext,
      doMovePrevious,
      doAddNew,
      doUpdate,
      doDelete
   };

	CADORecordset(CADODatabase* pDb, int nCacheSize = -1);
	virtual ~CADORecordset();

   CADORecordset& SetCacheSize(int nCacheSize) { m_pRS->CacheSize = nCacheSize; return *this; }
   BOOL Open(CString strSQL);

   CADORecordset& Close() { if (IsOpen()) m_pRS->Close(); return *this; }

   BOOL MoveNext() { return PerformAction(doMoveNext); }
   BOOL MoveFirst() { return PerformAction(doMoveFirst); }
   BOOL MoveLast() { return PerformAction(doMoveLast); }
   BOOL MovePrevious() { return PerformAction(doMovePrevious); }
   BOOL AddNew() { return PerformAction(doAddNew); }
   BOOL Update() { return PerformAction(doUpdate); }
   BOOL Delete() { return PerformAction(doDelete); }
   
   long GetFieldCount() {  return m_pRS->Fields->GetCount(); };
   long GetRecordCount();

	BOOL GetFieldValue(LPCTSTR lpFieldName, int& nValue);
	BOOL GetFieldValue(int nIndex, int& nValue);
	BOOL GetFieldValue(LPCTSTR lpFieldName, long& lValue);
	BOOL GetFieldValue(int nIndex, long& lValue);
	BOOL GetFieldValue(LPCTSTR lpFieldName, unsigned long& ulValue);
	BOOL GetFieldValue(int nIndex, unsigned long& ulValue);
	BOOL GetFieldValue(LPCTSTR lpFieldName, double& dbValue);
	BOOL GetFieldValue(int nIndex, double& dbValue);
	BOOL GetFieldValue(LPCTSTR lpFieldName, CString& strValue, CString strDateFormat = _T(""));
	BOOL GetFieldValue(int nIndex, CString& strValue, CString strDateFormat = _T(""));
	BOOL GetFieldValue(LPCTSTR lpFieldName, COleDateTime& time);
	BOOL GetFieldValue(int nIndex, COleDateTime& time);
	BOOL GetFieldValue(int nIndex, COleCurrency& cyValue);
	BOOL GetFieldValue(LPCTSTR lpFieldName, COleCurrency& cyValue);
	BOOL GetFieldValue(int nIndex, _variant_t& vtValue);
	BOOL GetFieldValue(LPCTSTR lpFieldName, _variant_t& vtValue);
 
   BOOL SetFieldValue(int nIndex, int nValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, int nValue);
	BOOL SetFieldValue(int nIndex, long lValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, long lValue);
	BOOL SetFieldValue(int nIndex, unsigned long lValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, unsigned long lValue);
	BOOL SetFieldValue(int nIndex, double dblValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, double dblValue);
	BOOL SetFieldValue(int nIndex, CString strValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, CString strValue);
	BOOL SetFieldValue(int nIndex, COleDateTime time);
	BOOL SetFieldValue(LPCTSTR lpFieldName, COleDateTime time);
	BOOL SetFieldValue(int nIndex, bool bValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, bool bValue);
	BOOL SetFieldValue(int nIndex, COleCurrency cyValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, COleCurrency cyValue);
	BOOL SetFieldValue(int nIndex, _variant_t vtValue);
	BOOL SetFieldValue(LPCTSTR lpFieldName, _variant_t vtValue);

	BOOL SetFieldEmpty(int nIndex);
	BOOL SetFieldEmpty(LPCTSTR lpFieldName);

   inline BOOL IsEOF() { return m_pRS->bEOF == VARIANT_TRUE; }
   inline BOOL IsOpen() { return m_pRS->GetState() != adStateClosed; }

protected:
   void SetRecordBinding(CADORecordBinding* pADOBinding); // used by derived record sets to bind data members

private:
   _RecordsetPtr m_pRS;
   CADODatabase* m_pDb;
   BOOL m_bOK;
   IADORecordBinding*  m_pPicRS; // binding interface from the RS 
   CADORecordBinding* m_pAdoRecordBinding; //interface implemented by derived classes that want to use binding.
   BOOL PerformAction(Actions doAction);
   BOOL PutFieldValue(LPCTSTR lpFieldName, _variant_t vtFld);
	BOOL PutFieldValue(_variant_t vtIndex, _variant_t vtFld);
};

#endif // !defined(AFX_ADORECORDSET_H__2A47DE61_A977_11D6_9A62_00D0B7E45CC5__INCLUDED_)
