// ADODatabase.h: interface for the CADODatabase class.
//
//////////////////////////////////////////////////////////////////////////////
//*****************************< ADODatabase.h >*****************************
//
//
//  Project.. : MFC ADO Related Tools                            
//  Author... : Tim Kohler                                                   
//  Date..... : 08/07/2002                                                    
//  Revision. : 00/00/0000                                                    
//  Library.. : DwEtlLib - Dynamic Link Library                             
//
//-----------------------------------------------------------------------------
//  Classes Defined 
//  ---------------
//
//  CADODatabase:   This class encapsulates the ADO Connection interface.  The
//                  interface is designed to be reasonably similar to the ODBC
//                  MFC database class CDatabase.
//
//  For more detailed information on ADO and numerous C++ examples, please 
//  browse the following websites:
//
//   http://codeguru.earthweb.com/mfc_database/Ado_Aok.shtml
//   http://msdn.microsoft.com/library/default.asp?url=/library/en-us/ado270/htm/mdmthaddnewxvc.asp
//   http://www.codeproject.com/database/#ADO
//
//*****************************************************************************

#if !defined(AFX_ADODATABASE_H__2A47DE62_A977_11D6_9A62_00D0B7E45CC5__INCLUDED_)
#define AFX_ADODATABASE_H__2A47DE62_A977_11D6_9A62_00D0B7E45CC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning(disable:4146)
#import "c:\program files\common files\system\ado\msado15.dll" named_guids rename("EOF", "bEOF") rename("BOF", "bBOF")
#pragma warning(default:4146)
using namespace ADODB;  

class CADORecordset; 

class AFX_EXT_CLASS CADODatabase 
{
friend CADORecordset;

public:
   enum DbActions
   {
      doClose,
      doBeginTrans,
      doCommitTrans,
      doRollbackTrans
   };

	CADODatabase();
   BOOL Open(CString strDB, CString strUID, CString strPWD, CString strProvider = "MSDASQL");
   inline BOOL Close() { return PerformAction(doClose); }
	virtual ~CADODatabase();
   inline BOOL IsOk() { return m_bOK;} 
   BOOL IsOpen();
   BOOL ExecuteSQL(CString strSQL);

//transaction support:
   BOOL BeginTrans() { return PerformAction(doBeginTrans); }
   BOOL CommitTrans() { return PerformAction(doCommitTrans); }
   BOOL RollbackTrans() { return PerformAction(doRollbackTrans); }

private:
   _ConnectionPtr m_pIConn;
   BOOL m_bOK;
   BOOL PerformAction(DbActions doAction);
};

#endif // !defined(AFX_ADODATABASE_H__2A47DE62_A977_11D6_9A62_00D0B7E45CC5__INCLUDED_)
