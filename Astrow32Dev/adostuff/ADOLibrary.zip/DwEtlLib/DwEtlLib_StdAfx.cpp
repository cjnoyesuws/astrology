// stdafx.cpp : source file that includes just the standard includes
//	DwEtlLib.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "DwEtlLib_StdAfx.h"


CString IntToStr(int nVal)
{
	CString strRet;
	char buff[20];
	
	itoa(nVal, buff, 10);
	strRet = buff;
	return strRet;
}

CString LongToStr(long lVal)
{
	CString strRet;
	char buff[20];
	
	ltoa(lVal, buff, 10);
	strRet = buff;
	return strRet;
}

CString ULongToStr(unsigned long ulVal)
{
	CString strRet;
	char buff[20];
	
	ultoa(ulVal, buff, 10);
	strRet = buff;
	return strRet;

}


CString DblToStr(double dblVal, int ndigits)
{
	CString strRet;
	char buff[50];
 
   _gcvt(dblVal, ndigits, buff);
	strRet = buff;
	return strRet;
}

CString DblToStr(float fltVal)
{
	CString strRet = _T("");
	char buff[50];
	
   _gcvt(fltVal, 10, buff);
	strRet = buff;
	return strRet;
}

