//*****************************< ADORecordset.cpp >*****************************
//
//
//  Project.. : NtrcAdoLib - MFC ADO Related Tools                            
//  Author... : Tim Kohler                                                   
//  Date..... : 08/07/2002                                                    
//  Revision. : 00/00/0000                                                    
//  Library.. : NtrcAdoLib - Dynamic Link Library                             
//  Notice... : Copyright (c) 2002, NORTHERN TRUST RETIREMENT CONSULTING, LLC 
//              All rights reserved                                           
//
//-----------------------------------------------------------------------------
//  Classes Defined 
//  ---------------
//
//  CADORecordset:  This class encapsulates the ADO Recordset interface.  The
//                  interface is designed to be reasonably similar to the ODBC
//                  MFC database class CRecordset.  The class supports dynamic
//                  binding as well as static binding.  All exception handling 
//                  related to managing COM and memory issues is contained w/in 
//                  this class.                
//
//
//   STATIC BINDING:
//                  To support static binding, a 'record' class must be created
//                  separately.  This record class must multiply inherit from CADORecordBinding
//                  and CADORecordset.  This closely approximates the interface of
//                  derived CRecordsets (except that the CRecordsets just define
//                  DoFieldExchange but here we implement CADORecordBinding).
//                  Here is a super simple example of one such class:
//
//       
//                  class CClientPlanRS : public CADORecordBinding, public CADORecordset
//                  {
//                      BEGIN_ADO_BINDING(CClientPlanRS)
//                      ADO_FIXED_LENGTH_ENTRY    (  1, adInteger, m_lClient_id, m_ulClient_idStatus, TRUE)
//                      ADO_VARIABLE_LENGTH_ENTRY2(  2, adVarChar, m_szClient_id_name, sizeof(m_szClient_id_name), m_ulClient_id_nameStatus, TRUE)
//                      ADO_VARIABLE_LENGTH_ENTRY2(  3, adVarChar, m_szClient_id_desc, sizeof(m_szClient_id_desc), m_ulClient_id_descStatus, TRUE)
//                      END_ADO_BINDING()
//
//                      //Attributes
//                      public:
//                      CClientPlanRS(CADODatabase* pDb = NULL, int nCacheSize = -1) : 
//                            CADORecordBinding(),
//                            CADORecordset(pDb, nCacheSize) 
//                         { SetRecordBinding(this); };
//
//                      LONG			m_lClient_id;
//                      ULONG			m_ulClient_idStatus;
//                      CHAR			m_szClient_id_name[51];
//                      ULONG			m_ulClient_id_nameStatus;
//                      CHAR			m_szClient_id_desc[51];
//                      ULONG			m_ulClient_id_descStatus;
//                   };
//
//
//
//       If you are familiar w/ the MFC class wizard you are already aware
//       of how nice it is when deriving a class from CRecordset (i.e. generating
//       the RFX and class data members that map to the table's columns).
//       Although there is no wizard integrated w/ developer studio to generate
//       the classes deriving from CADORecordBinding, a freeware wizard was 
//       found that takes all the work out of creating these classes.  It can be 
//       found at \\atl-d1-pdc-01\develop\tim\ADOWizard\ADORsWizard.exe.
//
//
//       Once the 'record' class has been created, just create a constructor as above 
//       call SetRecordBinding after calling the base class constructors.
//
//       Here are a couple of examples of using CADORecordset, CADODatabase, and
//       the above record statically bound recordset:
//
//
//       bOpen = db.Open("CLIMET", "TDK2", "NOONHIGH");
//
//       CClientPlanRS CliRs(&db);
//
//
//       //read table:
//       bRsOpen = CliRs.Open("select * from client_dim");
//   
//       while (!CliRs.IsEOF())
//       {
//         //do something w/ the records
//         CliRs.MoveNext();
//       }
//
//       //update the first existing row:
//       CliRs.MoveFirst();
//
//       strcpy(CliRs.m_szClient_id_name, "MOTOR999");      
//       BOOL bUpdate = CliRs.Update();
//
//       //add a new row:
//       CliRs.m_lClient_id = 999;
//       strcpy(CliRs.m_szClient_id_name, "SCHLUM");      
//       strcpy(CliRs.m_szClient_id_desc, "Schlumberger Inc");
//       BOOL bAdd = CliRs.AddNew();
//
//
//
//       DYNAMIC BINDING:
//             Static binding gives performance increases when the
//       layout of a query's response is known.  However, there are 
//       countless times when the desire may be to perform a 
//       strange query (i.e. calling an SQL function like COUNT, or
//       performing a join) where creating a static 'record' class
//       to bind is simply not worthwhile.  In addition there sometimes
//       arise cases where programs need to 'explore' a table's layout
//       and need to be able to query w/o knowing exactly what they'll
//       get in return (see ExtractBuilder and VcDef).  Dynamic binding
//       is excellent in these cases.  
//             CADORecordset (in conjunction with the _variant_t class)
//       provides an interface similar to that of CRecordset and CDbVariant.
//       In particular the GetRecordCount and GetFieldCount methods are
//       well suited for determining the basic shape (often used to determine
//       loop boundaries) of a query's result.  
//             Calling the GetFieldValue(int nIndex, _variant_t& vtValue)
//       method of the recordset will return the data in a single field w/in
//       a single record.  The type (vtValue.vt) tells where to look in the
//       union for the field's data. 
//             
//             In addition Dynamic binding may be used when a query's
//       response is known.  This is the typical way VB code uses ADO
//       with its queries.  Here is an example of executing a query 
//       and retrieving the results in this fashion:
//
//       // use the jet to read, we know the layout each record so we call the getfieldvalues w/
//       // the pre-known datatypes for the columns.	
//       CADODatabase db;
//
//       BOOL bOpen = db.Open("s:\\tim\\climet.mdb", "Admin", "", "Microsoft.Jet.OLEDB.3.51");
//       CADORecordset rs(&db);   
//
//       BOOL bRsOpen = rs.Open("select * from client_dim");
//
//       int nRows = rs.GetRecordCount();
//
//       int nKey;
//       CString strCliNm, strCliDesc;
//
//       BOOL fok = TRUE;
//
//       fok = rs.GetFieldValue(0, nKey);
//       fok = rs.GetFieldValue(1, strCliNm);
//       fok = rs.GetFieldValue(2, strCliDesc);
//   
//       db.Close();
//
//
//  For more detailed information on ADO and numerous C++ examples, please 
//  browse the following websites:
//
//   http://codeguru.earthweb.com/mfc_database/Ado_Aok.shtml
//   http://msdn.microsoft.com/library/default.asp?url=/library/en-us/ado270/htm/mdmthaddnewxvc.asp
//   http://www.codeproject.com/database/#ADO
//
//*****************************************************************************


// ADORecordset.cpp: implementation of the CADORecordset class.
//
//////////////////////////////////////////////////////////////////////

#include "DwEtlLib_stdafx.h"
#include "ADORecordset.h"
#include "ADODatabase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//*****************************************************************************
//
//  METHOD:       CADORecordset::CADORecordset(CADODatabase* pDb, 
//                                        CADORecordBinding *pAdoRecordBinding, 
//                                        int nCacheSize)
//
//  Arguments:    pDb               -- an open connection to the desired database.
//                pAdoRecordBinding -- optional -- interface implemented for
//                                     static binding support.
//                nCacheSize        -- initial cache size of the recordset.  This
//                                     dictates the # of rows fetched at a time 
//                                     from the DB server.
//
//  Returns:      nothing
//
//  Description:  This is the class constructor.  The constuctor initializes
//                the COM libraries and creates an instance of an ADO recordset
//                interface.  Please note that creating multiple instances
//                of this class is fine because subsequent calls to CoInitialize
//                do not load the library multiple times.  Rather COM keeps
//                a count of the number of calls to init and keeps the library
//                loaded until CoUninitialize is called an equal # of times.
//
//                Note on concurrency:  Do not pass instances of CADORecordset
//                between threads.  This is not likely to work properly because 
//                access to the recordset and its database object will not be 
//                sychronized.
//                Obviously this could be solved by making the recordset and its
//                database object marshal and demarshal the recordset and connection 
//                interface between the STA's of the threads but even then certain
//                threads might end up waiting for access to the recordset or database.
//                It is much more efficient to simply create and use the CADORecordset
//                and CADODatabase objects locally in threads.
//
//*****************************************************************************
CADORecordset::CADORecordset(CADODatabase* pDb, int nCacheSize) :
   m_pPicRS(NULL), m_pDb(pDb), m_bOK(TRUE), m_pAdoRecordBinding(NULL)
{
   try
   {
      TESTHR(CoInitialize(NULL));
      TESTHR(m_pRS.CreateInstance(__uuidof(Recordset)));     
      if (nCacheSize != -1)
         m_pRS->CacheSize = nCacheSize;
   }
   catch(...)
   {
      m_bOK = FALSE;
   }
}

//*****************************************************************************
//
//  METHOD:       CADORecordset::~CADORecordset()
//
//  Description:  This is the class destructor.  The recordset is closed 
//                if it is still open and the COM library reference counter
//                is decremented.
//
//*****************************************************************************
CADORecordset::~CADORecordset()
{
   try
   {
      if (m_pPicRS)
         m_pPicRS->Release();

      if (IsOpen())
         m_pRS->Close();

      m_pRS->Release();
      
      CoUninitialize();
   }
   catch(...)
   {
      ASSERT(TRUE);
   }
}


void CADORecordset::SetRecordBinding(CADORecordBinding* pADOBinding)
{
   try
   {
      if (m_pAdoRecordBinding || m_pPicRS)
      {
         ASSERT(FALSE);
         m_bOK = FALSE;
         return;
      }

      m_pAdoRecordBinding = pADOBinding;

      if (m_pAdoRecordBinding)
         TESTHR(m_pRS->QueryInterface(__uuidof(IADORecordBinding), (LPVOID*)&m_pPicRS ));
   }
   catch(...)
   {
      m_bOK = FALSE;
      ASSERT(FALSE);
   }
}


//*****************************************************************************
//
//  METHOD:       BOOL CADORecordset::Open(CString strSQL)
//
//  Arguments:    strSQL -- SQL statement that produces results that are
//                          cached in the recordset.
//
//  Returns:      TRUE if the query successfully executed and the recordset
//                was opened.
//
//  Description:  This method opens the recordset by executing the specified
//                query.  It performs static binding if necessary.  This query 
//                may be a simple query, an SQL function call, a join, etc.
//
//*****************************************************************************
BOOL CADORecordset::Open(CString strSQL)
{
   try
   {     
      TESTHR(m_pRS->Open(_bstr_t(strSQL), m_pDb->m_pIConn.GetInterfacePtr(), adOpenDynamic, adLockOptimistic, adCmdText));
      if (m_pPicRS && m_pAdoRecordBinding)
         TESTHR(m_pPicRS->BindToRecordset(m_pAdoRecordBinding));
   }
   catch(_com_error e)
   {
      //AfxMessageBox(e.ErrorMessage());
      return FALSE;
   }
   catch(...)
   {
      //AfxMessageBox("Unable to open recordset.");
      return FALSE;
   }

   return TRUE;
}

//*****************************************************************************
//
//  METHOD:       BOOL CADORecordset::PerformAction(Actions doAction)
//
//  Arguments:    doAction -- action to be executed.
//
//  Returns:      TRUE if the action successfully processed.
//
//  Description:  This method is here simply to centralize exception handling.
//
//*****************************************************************************
BOOL CADORecordset::PerformAction(Actions doAction)
{
   try
   {
      switch (doAction)
      {
         case doMoveNext:
            TESTHR(m_pRS->MoveNext());
            break;
         case doMoveFirst:
            TESTHR(m_pRS->MoveFirst());
            break;
         case doMoveLast:
            TESTHR(m_pRS->MoveLast());
            break;
         case doMovePrevious:
            TESTHR(m_pRS->MovePrevious());
            break;
         case doAddNew:
            if (m_pPicRS && m_pAdoRecordBinding)
            {
               TESTHR(m_pPicRS->AddNew(m_pAdoRecordBinding));
            }
            else
               TESTHR(m_pRS->AddNew());
            break;
         case doUpdate:
            if (m_pPicRS && m_pAdoRecordBinding)
               TESTHR(m_pPicRS->Update(m_pAdoRecordBinding));
            else
               TESTHR(m_pRS->Update());
            break;
         case doDelete:
            TESTHR(m_pRS->Delete(adAffectCurrent));
            break;
      };
   }
   catch(_com_error e)
   {
     //// AfxMessageBox(e.ErrorMessage());
     // AfxMessageBox(e.Source());
     // AfxMessageBox(e.Description());
      return FALSE;
   }
   catch(...)
   {
      AfxMessageBox("Unable to open database connection.");
      return FALSE;
   }  
   return TRUE;
}


//*****************************************************************************
//
//  METHOD:       BOOL CADORecordset::GetFieldValue( .. various overloads .. )
//
//  Arguments:    field name or index,
//                value of field
//
//  Returns:      TRUE if the field was successfully retrieved, FALSE if not.
//
//  Description:  These methods are used with dynamic binding to retrieve
//                values from records within a recordset.  They translate
//                the variant types to regular C++ types when requested.
//
//*****************************************************************************
BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, double& dbValue)
{	
	double val = (double)NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(lpFieldName)->Value;
		switch(vtFld.vt)
		{
		case VT_R4:
			val = vtFld.fltVal;
			break;
		case VT_R8:
			val = vtFld.dblVal;
			break;
		case VT_DECIMAL:
			val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10, vtFld.decVal.scale); 
			break;
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_I2:
		case VT_I4:
			val = vtFld.lVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = vtFld.dblVal;
		}
		dbValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}


BOOL CADORecordset::GetFieldValue(int nIndex, double& dbValue)
{	
	double val = (double)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt)
		{
		case VT_R4:
			val = vtFld.fltVal;
			break;
		case VT_R8:
			val = vtFld.dblVal;
			break;
		case VT_DECIMAL:
			val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10, vtFld.decVal.scale); 
			break;
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_I2:
		case VT_I4:
			val = vtFld.lVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = 0;
		}
		dbValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}


BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, long& lValue)
{
	long val = (long)NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(lpFieldName)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.lVal;
		lValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, long& lValue)
{
	long val = (long)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtFld = m_pRS->Fields->GetItem(vtIndex)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.lVal;
		lValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}


BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, unsigned long& ulValue)
{
	long val = (long)NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(lpFieldName)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.ulVal;
		ulValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, unsigned long& ulValue)
{
	long val = (long)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtFld = m_pRS->Fields->GetItem(vtIndex)->Value;
		if(vtFld.vt != VT_NULL && vtFld.vt != VT_EMPTY)
			val = vtFld.ulVal;
		ulValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, int& nValue)
{
	int val = NULL;
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(lpFieldName)->Value;
		switch(vtFld.vt)
		{
		case VT_BOOL:
			val = vtFld.boolVal;
			break;
		case VT_I2:
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = vtFld.iVal;
		}	
		nValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, int& nValue)
{
	int val = (int)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		vtFld = m_pRS->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt)
		{
		case VT_BOOL:
			val = vtFld.boolVal;
			break;
		case VT_I2:
		case VT_UI1:
			val = vtFld.iVal;
			break;
		case VT_INT:
			val = vtFld.intVal;
			break;
		case VT_NULL:
		case VT_EMPTY:
			val = 0;
			break;
		default:
			val = vtFld.iVal;
		}	
		nValue = val;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, CString& strValue, CString strDateFormat)
{
	CString str = _T("");
	_variant_t vtFld;

	try
	{
		vtFld = m_pRS->Fields->GetItem(lpFieldName)->Value;
		switch(vtFld.vt) 
		{
		case VT_R4:
			str = DblToStr(vtFld.fltVal);
			break;
		case VT_R8:
			str = DblToStr(vtFld.dblVal);
			break;
		case VT_BSTR:
			str = vtFld.bstrVal;
			break;
		case VT_I2:
		case VT_UI1:
			str = IntToStr(vtFld.iVal);
			break;
		case VT_INT:
			str = IntToStr(vtFld.intVal);
			break;
		case VT_I4:
			str = LongToStr(vtFld.lVal);
			break;
		case VT_UI4:
			str = ULongToStr(vtFld.ulVal);
			break;
		case VT_DECIMAL:
			{
			double val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10, vtFld.decVal.scale); 
			str = DblToStr(val);
			}
			break;
		case VT_DATE:
			{
				COleDateTime dt(vtFld);

				if(strDateFormat.IsEmpty())
					strDateFormat = _T("%Y-%m-%d %H:%M:%S");
				str = dt.Format(strDateFormat);
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			str.Empty();
			break;
		default:
			str.Empty();
			return FALSE;
		}
		strValue = str;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, CString& strValue, CString strDateFormat)
{
	CString str = _T("");
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt) 
		{
		case VT_R4:
			str = DblToStr(vtFld.fltVal);
			break;
		case VT_R8:
			str = DblToStr(vtFld.dblVal);
			break;
		case VT_BSTR:
			str = vtFld.bstrVal;
			break;
		case VT_I2:
		case VT_UI1:
			str = IntToStr(vtFld.iVal);
			break;
		case VT_INT:
			str = IntToStr(vtFld.intVal);
			break;
		case VT_I4:
			str = LongToStr(vtFld.lVal);
			break;
		case VT_UI4:
			str = ULongToStr(vtFld.ulVal);
			break;
		case VT_DECIMAL:
			{
			double val = vtFld.decVal.Lo32;
			val *= (vtFld.decVal.sign == 128)? -1 : 1;
			val /= pow(10, vtFld.decVal.scale); 
			str = DblToStr(val);
			}
			break;
		case VT_DATE:
			{
				COleDateTime dt(vtFld);
				
				if(strDateFormat.IsEmpty())
					strDateFormat = _T("%Y-%m-%d %H:%M:%S");
				str = dt.Format(strDateFormat);
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			str.Empty();
			break;
		default:
			str.Empty();
			return FALSE;
		}
		strValue = str;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, COleDateTime& time)
{
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(lpFieldName)->Value;
		switch(vtFld.vt) 
		{
		case VT_DATE:
			{
				COleDateTime dt(vtFld);
				time = dt;
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			time.SetStatus(COleDateTime::null);
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, COleDateTime& time)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt) 
		{
		case VT_DATE:
			{
				COleDateTime dt(vtFld);
				time = dt;
			}
			break;
		case VT_EMPTY:
		case VT_NULL:
			time.SetStatus(COleDateTime::null);
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}




BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, COleCurrency& cyValue)
{
	_variant_t vtFld;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(lpFieldName)->Value;
		switch(vtFld.vt) 
		{
		case VT_CY:
			cyValue = (CURRENCY)vtFld.cyVal;
			break;
		case VT_EMPTY:
		case VT_NULL:
			{
			cyValue = COleCurrency();
			cyValue.m_status = COleCurrency::null;
			}
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, COleCurrency& cyValue)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtFld = m_pRS->Fields->GetItem(vtIndex)->Value;
		switch(vtFld.vt) 
		{
		case VT_CY:
			cyValue = (CURRENCY)vtFld.cyVal;
			break;
		case VT_EMPTY:
		case VT_NULL:
			{
			cyValue = COleCurrency();
			cyValue.m_status = COleCurrency::null;
			}
			break;
		default:
			return FALSE;
		}
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(LPCTSTR lpFieldName, _variant_t& vtValue)
{
	try
	{
		vtValue = m_pRS->Fields->GetItem(lpFieldName)->Value;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

BOOL CADORecordset::GetFieldValue(int nIndex, _variant_t& vtValue)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		vtValue = m_pRS->Fields->GetItem(vtIndex)->Value;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

//*****************************************************************************
//
//  METHOD:       BOOL CADORecordset::SetFieldValue( .. various overloads .. )
//
//  Arguments:    field name or index,
//                value of field
//
//  Returns:      TRUE if the field was successfully set, FALSE if not.
//
//  Description:  These methods are used with dynamic binding to set
//                values in records within a recordset.  They translate
//                the C++ types to variant types.
//
//*****************************************************************************
BOOL CADORecordset::SetFieldValue(int nIndex, CString strValue)
{
	_variant_t vtFld;
	_variant_t vtIndex;	
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	if(!strValue.IsEmpty())
		vtFld.vt = VT_BSTR;
	else
		vtFld.vt = VT_NULL;

	vtFld.bstrVal = strValue.AllocSysString();

	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, CString strValue)
{
	_variant_t vtFld;

	if(!strValue.IsEmpty())
		vtFld.vt = VT_BSTR;
	else
		vtFld.vt = VT_NULL;

	vtFld.bstrVal = strValue.AllocSysString();

	return PutFieldValue(lpFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, int nValue)
{
	_variant_t vtFld;
	
	vtFld.vt = VT_I2;
	vtFld.iVal = nValue;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, int nValue)
{
	_variant_t vtFld;
	
	vtFld.vt = VT_I2;
	vtFld.iVal = nValue;
	
	
	return PutFieldValue(lpFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, long lValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_I4;
	vtFld.lVal = lValue;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
	
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, long lValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_I4;
	vtFld.lVal = lValue;
	
	return PutFieldValue(lpFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, unsigned long ulValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_UI4;
	vtFld.ulVal = ulValue;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
	
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, unsigned long ulValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_UI4;
	vtFld.ulVal = ulValue;
	
	return PutFieldValue(lpFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, double dblValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_R8;
	vtFld.dblVal = dblValue;

	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, double dblValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_R8;
	vtFld.dblVal = dblValue;
		
	return PutFieldValue(lpFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, COleDateTime time)
{
	_variant_t vtFld;
	vtFld.vt = VT_DATE;
	vtFld.date = time;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, COleDateTime time)
{
	_variant_t vtFld;
	vtFld.vt = VT_DATE;
	vtFld.date = time;
	
	return PutFieldValue(lpFieldName, vtFld);
}



BOOL CADORecordset::SetFieldValue(int nIndex, bool bValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_BOOL;
	vtFld.boolVal = bValue;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, bool bValue)
{
	_variant_t vtFld;
	vtFld.vt = VT_BOOL;
	vtFld.boolVal = bValue;
	
	return PutFieldValue(lpFieldName, vtFld);
}


BOOL CADORecordset::SetFieldValue(int nIndex, COleCurrency cyValue)
{
	if(cyValue.m_status == COleCurrency::invalid)
		return FALSE;

	_variant_t vtFld;
		
	vtFld.vt = VT_CY;
	vtFld.cyVal = cyValue.m_cur;
	
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtFld);
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, COleCurrency cyValue)
{
	if(cyValue.m_status == COleCurrency::invalid)
		return FALSE;

	_variant_t vtFld;

	vtFld.vt = VT_CY;
	vtFld.cyVal = cyValue.m_cur;	
		
	return PutFieldValue(lpFieldName, vtFld);
}

BOOL CADORecordset::SetFieldValue(int nIndex, _variant_t vtValue)
{
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	return PutFieldValue(vtIndex, vtValue);
}

BOOL CADORecordset::SetFieldValue(LPCTSTR lpFieldName, _variant_t vtValue)
{	
	return PutFieldValue(lpFieldName, vtValue);
}



//*****************************************************************************
//
//  METHOD:       BOOL CADORecordset::PutFieldValue(LPCTSTR lpFieldName,
//                                      _variant_t vtFld)
//
//  Arguments:    lpFieldName field name,
//                vtFld value of field
//
//  Returns:      TRUE if the field was successfully set, FALSE if not.
//
//  Description:  This method is used with dynamic binding to set
//                values in records within a recordset.  The specified 
//                variant value is written to the proper spot in the 
//                Fields collection.
//
//*****************************************************************************
BOOL CADORecordset::PutFieldValue(LPCTSTR lpFieldName, _variant_t vtFld)
{
	try
	{
		m_pRS->Fields->GetItem(lpFieldName)->Value = vtFld; 
		return TRUE;
	}
	catch(...)
	{
		return FALSE;	
	}
}

//*****************************************************************************
//
//  METHOD:       BOOL CADORecordset::PutFieldValue(_variant_t vtIndex,
//                                      _variant_t vtFld)
//
//  Arguments:    vtIndex index of the field w/in the Fields collection.
//                vtFld value of field
//
//  Returns:      TRUE if the field was successfully set, FALSE if not.
//
//  Description:  This method is used with dynamic binding to set
//                values in records within a recordset.  The specified 
//                variant value is written to the proper spot in the 
//                Fields collection.
//
//*****************************************************************************
BOOL CADORecordset::PutFieldValue(_variant_t vtIndex, _variant_t vtFld)
{
	try
	{
		m_pRS->Fields->GetItem(vtIndex)->Value = vtFld;
		return TRUE;
	}
	catch(...)
	{
		return FALSE;
	}
}

//*****************************************************************************
//
//  METHOD:       long CADORecordset::GetRecordCount()
//
//
//  Returns:      # of rows currently in the recordset.
//
//  Description:  This method is used to determine the # of rows fetched.
//
//*****************************************************************************
long CADORecordset::GetRecordCount()
{
	DWORD nRows = 0;

   if (IsOpen())
   {	
   	nRows = m_pRS->GetRecordCount();
   
	   if(nRows == -1)
	   {
		   nRows = 0;
		   if(m_pRS->bEOF != VARIANT_TRUE)
			   m_pRS->MoveFirst();
		
		   while(m_pRS->bEOF != VARIANT_TRUE)
		   {
			   nRows++;
			   m_pRS->MoveNext();
		   }
		   if(nRows > 0)
			   m_pRS->MoveFirst();
	   }
   }
	
	return (long)nRows;
}