//*****************************< ADODatabase.cpp >***************************
//
//  Project.. : NtrcAdoLib - MFC ADO Related Tools                            
//  Author... : Tim Kohler                                                   
//  Date..... : 08/07/2002                                                    
//  Revision. : 00/00/0000                                                    
//  Library.. : NtrcAdoLib - Dynamic Link Library                             
//  Notice... : Copyright (c) 2002, NORTHERN TRUST RETIREMENT CONSULTING, LLC 
//              All rights reserved                                           
//
//-----------------------------------------------------------------------------
//                            CLASSES IMPLEMENTED 
//-----------------------------------------------------------------------------
//
//  CADODatabase:   This class encapsulates the ADO Connection interface.  The
//                  interface is designed to be reasonably similar to the ODBC
//                  MFC database class CDatabase.  All exception handling related
//                  to managing COM and memory issues is contained w/in this
//                  class.                
//
//
//*****************************************************************************
// ADODatabase.cpp: implementation of the CADODatabase class.
//
//////////////////////////////////////////////////////////////////////

#include "DwEtlLib_stdafx.h"
#include "ADODatabase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


//*****************************************************************************
//
//  METHOD:       CADODatabase::CADODatabase()
//
//  Description:  This is the class constructor.  The constuctor initializes
//                the COM libraries and creates an instance of an ADO connection
//                interface.  Please note that creating multiple instances
//                of this class is fine because subsequent calls to CoInitialize
//                do not load the library multiple times.  Rather COM keeps
//                a count of the number of calls to init and keeps the library
//                loaded until CoUninitialize is called an equal # of times.
//
//                Note on concurrency:  Do not pass instances of CADODatabase
//                between threads.  This is not likely to work properly because 
//                access to the database object will not be sychronized.
//                Obviously this could be solved by making the database object
//                marshal and demarshal the connection interface between the
//                STA's of the threads but even then certain threads might end up
//                waiting for access to the database.  It is much more efficient
//                to simply create and use the CADODatabase objects locally in
//                threads.
//
//*****************************************************************************
CADODatabase::CADODatabase() : m_bOK(TRUE)
{   
   try
   {
      TESTHR(CoInitialize(NULL));
      TESTHR(m_pIConn.CreateInstance(CLSID_Connection));
   }
   catch(_com_error e)
   {
      AfxMessageBox(e.ErrorMessage());
      m_bOK = FALSE;
   }
   catch(...)
   {
      AfxMessageBox("Unable to open database connection.");
      m_bOK = FALSE;
   }
}

//*****************************************************************************
//
//  METHOD:       CADODatabase::~CADODatabase()
//
//  Description:  This is the class destructor.  The connection is closed 
//                if it is still open and the COM library reference counter
//                is decremented.
//
//*****************************************************************************
CADODatabase::~CADODatabase()
{
   try
   {
      if (IsOpen())
         m_bOK = Close();

      m_pIConn->Release();

      CoUninitialize();
   }
   catch(...)
   {
      ASSERT(TRUE);
   }
}

//*****************************************************************************
//
//  METHOD:       BOOL CADODatabase::ExecuteSQL(CString strSQL)
//
//  Argument:     strSQL -- SQL to execute.
//
//  Returns:      TRUE if the SQL was successfully executed.
//
//  Description:  This method is provided to allow SQL to be directly
//                executed against the datasource.  Any valid SQL is allowed
//                provided it returns nothing.  If you need SQL that returns 
//                a recordset or even a single record or value, use CADORecordset
//                in conjunction w/ CADODatabase.
//
//*****************************************************************************
BOOL CADODatabase::ExecuteSQL(CString strSQL)
{
   try
   {
      m_pIConn->Execute(_bstr_t(strSQL), NULL, adCmdText);  
   }
   catch(...)
   {
      m_bOK = FALSE;
      return FALSE;
   }

   return TRUE;
}

//*****************************************************************************
//
//  METHOD:       BOOL CADODatabase::Open(CString strDB, CString strUID, 
//                                        CString strPWD, CString strProvider)
//
//  Argument:     strDB --  DB name.  This can vary depending on the provider
//                          utilized.  If the default provider is used
//                          this will be an DSN (ODBC).  If the jet provider
//                          is used this can be path and name of an .mdb.
//
//                strUID -- User ID used to log into DB.
//                strPWD -- Password used to log into DB.
//                strProvider -- defaults to the MS OLE DB provider for 
//                               ODBC (MSDASQL).  This can be any valid
//                               OLE DB provider.
//
//  Returns:      TRUE if the SQL was successfully executed.
//
//  Description:  This method is provided to allow SQL to be directly
//                executed against the datasource.  Any valid SQL is allowed
//                provided it returns nothing.  If you need SQL that returns 
//                a recordset or even a single record or value, use CADORecordset
//                in conjunction w/ CADODatabase.
//
//*****************************************************************************
//strProvider -- OLE DB provider to be used.  Defaults to use the 
//MS OLE DB provider for ODBC (MSDASQL).
//Microsoft.Jet.OLEDB.3.51 for the Jet (for MS Access databases)
BOOL CADODatabase::Open(CString strDB, CString strUID, CString strPWD, CString strProvider)
{
   try
   {
      m_pIConn->Provider = _bstr_t(strProvider);
      TESTHR(m_pIConn->Open(_bstr_t(strDB), _bstr_t(strUID), _bstr_t(strPWD), -1));
   }
   catch(...)
   {
      ASSERT(FALSE);
      m_bOK = FALSE;
      return FALSE;
   }

   return TRUE;
}


//*****************************************************************************
//
//  METHOD:       BOOL CADODatabase::IsOpen()
//
//  Returns:      TRUE if the DB is open, FALSE if not.
//
//  Description:  This method determines whether the database connection is
//                currently opened.
//
//*****************************************************************************
BOOL CADODatabase::IsOpen()
{
	if(m_pIConn)
		return m_pIConn->GetState() != adStateClosed;

	return FALSE;
}

//*****************************************************************************
//
//  METHOD:       BOOL CADODatabase::PerformAction(DbActions doAction)
//
//  Arguments:    doAction -- action to be executed.
//
//  Returns:      TRUE if the action successfully processed.
//
//  Description:  This method is here simply to centralize exception handling.
//
//*****************************************************************************
BOOL CADODatabase::PerformAction(DbActions doAction)
{
   try
   {
      switch (doAction)
      {
         case doClose:
            TESTHR(m_pIConn->Close());
            break;
         case doBeginTrans:
            m_pIConn->BeginTrans();
            break;
         case doCommitTrans:
            m_pIConn->CommitTrans();
            break;
         case doRollbackTrans:
            m_pIConn->RollbackTrans();
            break;       
      };
      return TRUE;
   }
   catch(_com_error e)  //this is only caught specifically so that you can easily look up problems when debugging.
   {
      ASSERT(FALSE);
      m_bOK = FALSE;
      return FALSE;
   }
   catch(...)
   {
      ASSERT(FALSE);
      m_bOK = FALSE;
      return FALSE;
   }
}
