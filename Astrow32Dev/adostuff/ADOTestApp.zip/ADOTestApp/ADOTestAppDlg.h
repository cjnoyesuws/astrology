// ADOTestAppDlg.h : header file
//

#if !defined(AFX_ADOTESTAPPDLG_H__A391F1EC_ABC0_11D6_9A63_00D0B7E45CC5__INCLUDED_)
#define AFX_ADOTESTAPPDLG_H__A391F1EC_ABC0_11D6_9A63_00D0B7E45CC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CADOTestAppDlg dialog

class CADOTestAppDlg : public CDialog
{
// Construction
public:
	CADOTestAppDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CADOTestAppDlg)
	enum { IDD = IDD_ADOTESTAPP_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CADOTestAppDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CADOTestAppDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADOTESTAPPDLG_H__A391F1EC_ABC0_11D6_9A63_00D0B7E45CC5__INCLUDED_)
