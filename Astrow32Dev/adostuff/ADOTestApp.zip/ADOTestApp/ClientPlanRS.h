#ifndef _CCLIENTPLANRS_H_
#define _CCLIENTPLANRS_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// Include the headers for the database and recordset classes: 
// MAKE SURE THE PATH TO THESE FILES IS IN THE PROJECT SETTINGS
#include "ADODatabase.h"
#include "ADORecordset.h"


// ClientPlanRS.h : header file
//

//Note: Remove this #define if you don't want it to be here...
#define DSN_CONNECT_STRING _T(  "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=E:\\ADOdb.mdb;Mode=Sh"\
"are Deny None;Extended Properties=\"\";Jet OLEDB:System database=\"\";Jet OL"\
"EDB:Registry Path=\"\";Jet OLEDB:Database Password=\"\";Jet OLEDB:Engine Typ"\
"e=4;Jet OLEDB:Database Locking Mode=0;Jet OLEDB:Global Partial Bulk Ops=2;Je"\
"t OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password=\"\";Jet "\
"OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLED"\
"B:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repai"\
"r=False;Jet OLEDB:SFP=False")

/////////////////////////////////////////////////////////////////////////////
// CClientPlanRS class

class CClientPlanRS : public CADORecordBinding, public CADORecordset
{
BEGIN_ADO_BINDING(CClientPlanRS)
	ADO_FIXED_LENGTH_ENTRY    (  1, adInteger, m_lClient_Key, m_ulClient_KeyStatus, TRUE)
	ADO_VARIABLE_LENGTH_ENTRY2(  2, adVarWChar, m_szClient_Name, sizeof(m_szClient_Name), m_ulClient_NameStatus, TRUE)
	ADO_VARIABLE_LENGTH_ENTRY2(  3, adVarWChar, m_szClient_Description, sizeof(m_szClient_Description), m_ulClient_DescriptionStatus, TRUE)
END_ADO_BINDING()

//Attributes
public:
	LONG			m_lClient_Key;
	ULONG			m_ulClient_KeyStatus;
	CHAR			m_szClient_Name[51];
	ULONG			m_ulClient_NameStatus;
	CHAR			m_szClient_Description[256];
	ULONG			m_ulClient_DescriptionStatus;
   CClientPlanRS(CADODatabase* pDb, int nCacheSize = -1) :  
            CADORecordBinding(),                        
            CADORecordset(pDb, nCacheSize)              
            { SetRecordBinding(this); } 

}; 

      //{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !_CCLIENTPLANRS_H_
