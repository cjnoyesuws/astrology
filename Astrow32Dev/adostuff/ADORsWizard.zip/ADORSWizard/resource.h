//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ADORsWizard.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ADORSWIZARD_DIALOG          102
#define IDS_PROPSHT_CAPTION             103
#define IDD_WIZPAGE1                    104
#define IDD_WIZPAGE2                    105
#define IDD_WIZPAGE3                    106
#define IDD_WIZPAGE4                    107
#define IDD_WIZPAGE5                    108
#define IDR_MAINFRAME                   128
#define IDC_HAND                        147
#define IDC_EDIT_CLASSNAME              1000
#define IDC_EDIT_CLASSFILE              1001
#define IDC_BUTTON_CHANGEFILE           1002
#define IDC_BUTTON_CHANGEDIR            1002
#define IDC_EDIT_BASECLASS              1003
#define IDC_LIST_TABLES                 1003
#define IDC_EDIT_DIRNAME                1003
#define IDC_URLTEXT                     1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
