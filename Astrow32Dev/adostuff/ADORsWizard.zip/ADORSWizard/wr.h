#ifndef _WR_H_
#define _WR_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// NOTE : In order to use this code against a different version of ADO, the appropriate
// ADO library needs to be used in the #import statement
#import "C:\Program Files\Common Files\System\ADO\msado15.dll" rename_namespace("ADOCG") rename("EOF", "EndOfFile")
using namespace ADOCG;
#include "icrsint.h"

#include "oledb.h"

// wr.h : header file
//

#define DSN_CONNECT_STRING _T("Provider=MSDASQL;Password=keymaster;Persist Security Info=True;User ID=sa;Data Source=SQL SERVER PRODUCTION;Extended Properties="DSN=SQL SERVER PRODUCTION;UID=sa;PWD=keymaster;APP=ADORsWizard Application;WSID=VADER;DATABASE=acces;Trusted_Connection=Yes";Initial Catalog=acces")

/////////////////////////////////////////////////////////////////////////////
// wr class

class wr : public CADORecordBinding
{
BEGIN_ADO_BINDING(wr)
	ADO_FIXED_LENGTH_ENTRY    (  1, adInteger, m_lStudentID, m_ulStudentIDStatus, TRUE)
	ADO_VARIABLE_LENGTH_ENTRY2(  2, adVarChar, m_szSSN, sizeof(m_szSSN), m_ulSSNStatus, TRUE)
	ADO_VARIABLE_LENGTH_ENTRY2(  3, adVarChar, m_szLastName, sizeof(m_szLastName), m_ulLastNameStatus, TRUE)
	ADO_VARIABLE_LENGTH_ENTRY2(  4, adVarChar, m_szFirstName, sizeof(m_szFirstName), m_ulFirstNameStatus, TRUE)
END_ADO_BINDING()

//Attributes
public:
	LONG			m_lStudentID;
	ULONG			m_ulStudentIDStatus;
	CHAR			m_szSSN[10];
	ULONG			m_ulSSNStatus;
	CHAR			m_szLastName[26];
	ULONG			m_ulLastNameStatus;
	CHAR			m_szFirstName[26];
	ULONG			m_ulFirstNameStatus;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !_WR_H_
