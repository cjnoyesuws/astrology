// ADORsWizardSheet.cpp : implementation file
//

#include "stdafx.h"
#include "ADORsWizard.h"
#include "ADORsWizardSheet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CADORsWizardSheet

IMPLEMENT_DYNAMIC(CADORsWizardSheet, CPropertySheet)

CADORsWizardSheet::CADORsWizardSheet(CWnd* pWndParent)
	 : CPropertySheet(IDS_PROPSHT_CAPTION, pWndParent)
{
	// Add all of the property pages here.  Note that
	// the order that they appear in here will be
	// the order they appear in on screen.  By default,
	// the first page of the set is the active one.
	// One way to make a different property page the 
	// active one is to call SetActivePage().

	AddPage(&m_Page1);
	AddPage(&m_Page2);
	m_bIsConnectionOpen = FALSE;
	SetWizardMode();
	m_pConnection = NULL;
}

CADORsWizardSheet::~CADORsWizardSheet()
{
}


BEGIN_MESSAGE_MAP(CADORsWizardSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CADORsWizardSheet)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDHELP, OnAbout)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CADORsWizardSheet message handlers



BOOL CADORsWizardSheet::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	SetWizardButtons(0);
	GetDlgItem(IDHELP)->SetWindowText("About...");
	return bResult;
}

BOOL CADORsWizardSheet::GetDBConnection()
{
	if(m_bIsConnectionOpen)
		return TRUE;

	HRESULT hr = S_OK;
	IDataSourceLocatorPtr dlPrompt = NULL;

     try
     {
       // Instantiate DataLinks object.
       TESTHR(hr = dlPrompt.CreateInstance(__uuidof(DataLinks)) );

       // Prompt for connection information.
       m_pConnection = dlPrompt->PromptNew();

       // If connection object is NULL, user cancelled.
       if ( NULL == m_pConnection ) 
		   return FALSE;

		// Open connection (connection returned by DataLinks is just
		// a holder for the returned ConnectionString).
		TESTHR(hr = m_pConnection->Open( m_pConnection->ConnectionString, L"", L"", -1 ) ); 
		m_bIsConnectionOpen = TRUE;

	 }
     catch ( _com_error &ce )
     {
		// Notify user of any errors that result from
        // executing the query.
 		GenerateProviderError(m_pConnection);
        GenerateComError(ce);
		if(m_pConnection != NULL)
			m_pConnection.Release();

		m_bIsConnectionOpen = FALSE;
	   return FALSE;
     }

	return TRUE;
}

void CADORsWizardSheet::PostNcDestroy() 
{
	CloseDBConnection();
	CPropertySheet::PostNcDestroy();
}

BOOL CADORsWizardSheet::FillListOfTables()
{
	CWaitCursor wait;
	_RecordsetPtr rs = NULL;

	CListBox * pListBox = &m_Page2.m_listboxTables;
	pListBox->ResetContent();

    try
	{
		// Get a list of tables and dump list to console.
		rs = m_pConnection->OpenSchema( adSchemaTables );

		while ( !rs->EndOfFile)
		{
			pListBox->AddString((char*) (_bstr_t) rs->Fields->Item[L"TABLE_NAME"]->Value );
			rs->MoveNext();
		}
    }
    catch ( _com_error &ce )
    {
		// Notify user of any errors that result from
        // executing the query.
        // Pass a connection pointer accessed from the Recordset.
        GenerateProviderError(m_pConnection);
        GenerateComError(ce);

		CloseDBConnection();
		return FALSE;
    }

	return TRUE;
}

void CADORsWizardSheet::GenerateComError(_com_error &e)
{
    // Generate COM errors. 
	CString strError;
	strError.Format(_T(	"Error\n"
						"\tCode = %08lx\n"
						"\tCode meaning = %s\n"
						"\tSource = %s\n"
						"\tDescription = %s\n"),
						e.Error(),
						e.ErrorMessage(),
						(LPCTSTR) e.Source(),
						(LPCTSTR) e.Description()
						);

	AfxMessageBox(strError);
}


void CADORsWizardSheet::GenerateProviderError(_ConnectionPtr pConnection)
{
 	if(pConnection == NULL)
		return;

   // Generate Provider Errors from Connection object.
    // pErr is a record object in the Connection's Error collection.
    ErrorPtr  pErr = NULL;
	CString strError;
    if( (pConnection->Errors->Count) > 0)
    {
        long nCount = pConnection->Errors->Count;
        // Collection ranges from 0 to nCount -1.
        for(long i = 0; i < nCount; i++)
        {
            pErr = pConnection->Errors->GetItem(i);
            strError.Format("Error number:\t%x\nDescription:\t%s", pErr->Number,
                (LPCSTR)pErr->Description);
			AfxMessageBox(strError);

        }
    }
}


void CADORsWizardSheet::CloseDBConnection()
{
	if(m_bIsConnectionOpen)
	{
		HRESULT hr = S_OK;
		try
		{
			TESTHR(hr = m_pConnection->Close() );
			m_pConnection.Release();
			m_bIsConnectionOpen = FALSE;
		}
		catch ( _com_error &ce )
		{
			// Notify user of any errors that result from
			// executing the query.
			// Pass a connection pointer accessed from the Recordset.
			GenerateProviderError(m_pConnection);
			GenerateComError(ce);
		}
	}

}

BOOL CADORsWizardSheet::GenerateFile()
{
	CWaitCursor wait;

	if(m_strTableName.IsEmpty())
		return FALSE;


    // Define ADO object pointers.
    // Initialize pointers on define.
    // These are in the ADODB::  namespace
    _RecordsetPtr   pRecordset  = NULL;
    FieldsPtr  fldLoop = NULL;    
	FieldPtr pField = NULL;

	CString strTableName(m_strTableName);
	if(strTableName.Find(_T(' ')) != -1 ) 
		strTableName = _T("[") + strTableName + _T("]");

	_bstr_t bstrTableName( strTableName);

    //Define Other Variables
    HRESULT  hr = S_OK;
    _variant_t Index;
    Index.vt = VT_I2;

	CString strMACRO;
	CString strAttributes;
    try
    {
        
        TESTHR(hr = pRecordset.CreateInstance(__uuidof(Recordset)) );
//        TESTHR(hr = pRecordset->Open( bstrTableName, _variant_t((IDispatch *)m_pConnection,true), adOpenForwardOnly,
//           adLockReadOnly, adCmdTable) );
        TESTHR(hr = pRecordset->Open( bstrTableName, _variant_t((IDispatch *)m_pConnection,true), adOpenKeyset,
            adLockOptimistic, adCmdTable) );

        fldLoop = pRecordset->GetFields();

        for (short i = 0; i < fldLoop->GetCount(); i++)
        {
            Index.iVal=i;
			CString strType;
			pField = fldLoop->GetItem(Index);
			CString strClassAttributes;
			CString strClassMACRO;

			CString strName;
			strName.Format("%s", (LPSTR)fldLoop->GetItem(Index)->GetName());
			strName.Remove(' '); //Remove spaces
			BuildClassBindingString(pField, strName,i , strClassAttributes, strClassMACRO);
			strAttributes += strClassAttributes;
			strMACRO += strClassMACRO;

        }

        // Clean up objects before exit.
        pRecordset->Close();
    }
	catch ( _com_error &ce )
	{
		// Notify user of any errors that result from
        // executing the query.
 	   GenerateProviderError(m_pConnection);
       GenerateComError(ce);
		return FALSE;

	}

	CString strOutputFile;

	CStdioFile fOutput;
	CFileException e;

	if(m_strDir.IsEmpty())
	{

		strOutputFile = m_strFileName;
	}
	else
	{
		if(m_strDir.Right(1) != "\\")
			strOutputFile = m_strDir + "\\" + m_strFileName;
		else
			strOutputFile = m_strDir + m_strFileName;
	}
	
	//Open file
	if(!fOutput.Open( strOutputFile, CFile::modeCreate|CFile::modeWrite, &e))
	{
#ifdef _DEBUG   
		afxDump << "File could not be opened " << e.m_cause << "\n";
#endif   

		return FALSE;
	}

	CString strConnect = (LPCTSTR)m_pConnection->GetConnectionString();
	strConnect.Replace( _T("\\"), _T("\\\\") );	
	strConnect.Replace( _T("\""), _T("\\\"") );	

	int nLen = strConnect.GetLength();
	int nInsertChar = 80;


	while(nInsertChar < nLen)
	{
		strConnect.Insert(nInsertChar, _T("\"\\\n\"") );
		nInsertChar += 80;
	}

	
	CString strText;
	CString strDef(m_strClassName);
	strDef.MakeUpper();

	//Collecting data 
	strText.Format( 
	"#ifndef _%s_H_\n"  \
	"#define _%s_H_\n\n" \

	"#if _MSC_VER >= 1000\n" 
	"#pragma once\n" \
	"#endif // _MSC_VER >= 1000\n\n" 
   "// Include the headers for the database and recordset classes: \n"
   "// MAKE SURE THE PATH TO THESE FILES IS IN THE PROJECT SETTINGS\n" 
   "#include \"ADODatabase.h\"\n"
   "#include \"ADORecordset.h\"\n\n\n"
	"// %s : header file\n" \
	"//\n\n" \
	
	"//Note: Remove this #define if you don't want it to be here...\n" \
	"#define DSN_CONNECT_STRING _T(  \"%s\")\n\n" \


	"/////////////////////////////////////////////////////////////////////////////\n" \
	"// %s class\n\n" \

	"class %s : public CADORecordBinding, public CADORecordset\n" \
	"{\n" \
	"BEGIN_ADO_BINDING(%s)\n", 
			strDef, 
			strDef,
			m_strFileName, 
			strConnect,
			m_strClassName, 
			m_strClassName, 
			m_strClassName
			);

	//Writing data to file
	fOutput.WriteString(strText);
	fOutput.WriteString(strMACRO);

	//Collecting data 
	strText = 
	"END_ADO_BINDING()\n\n" \
	"//Attributes\n"  \
	"public:\n";

	//Writing data to file
	fOutput.WriteString(strText);
	fOutput.WriteString(strAttributes);

	//Collecting data 
	strText.Format("   %s(CADODatabase* pDb, int nCacheSize = -1) :  \n"\
                  "            CADORecordBinding(),                        \n"\
                  "            CADORecordset(pDb, nCacheSize)              \n"\
                  "            { SetRecordBinding(this); } \n\n}; \n\n      "

	"//{{AFX_INSERT_LOCATION}}\n"	\
	"// Microsoft Developer Studio will insert additional declarations immediately before the previous line.\n\n" \

	"#endif // !_%s_H_\n", m_strClassName, strDef);

	//Writing data to file
	fOutput.WriteString(strText);
	
	//Close file
	fOutput.Close();

	return TRUE;

}

void CADORsWizardSheet::BuildClassBindingString(FieldPtr pField, LPCTSTR lpszName, int nIndex, CString& strClassAttributes, CString&  strClassMACRO)
{
	nIndex++;
	CString strDataType;
	char szMemberName[100] = {0};
	LONG   lDefinedSize		= pField->GetDefinedSize();
	BOOL bExcept = FALSE;
    int propType = (int)pField->GetType();

    switch(propType) 
    {
        case adBigInt:
            strDataType = "adBigInt";
			wsprintf(szMemberName , "m_li%s", lpszName);
            strClassAttributes.Format("\tLARGE_INTEGER\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adBinary:
			bExcept = TRUE;
            strDataType = "adBinary"; 
			wsprintf(szMemberName , "m_bt%s", lpszName);
            strClassAttributes.Format("\tBYTE\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize, lpszName );
            break;
        case adBoolean:
            strDataType = "adBoolean";
			wsprintf(szMemberName , "m_b%s", lpszName);
            strClassAttributes.Format("\tVARIANT_BOOL\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adBSTR:
            strDataType = "adBSTR";
			wsprintf(szMemberName , "m_bst%s", lpszName);
            strClassAttributes.Format("\tBSTR\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adChapter:
            strDataType = "adChapter";
            break;
        case adChar:
			bExcept = TRUE;
            strDataType = "adChar";
			wsprintf(szMemberName , "m_sz%s", lpszName);
            strClassAttributes.Format("\tCHAR\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize + 1, lpszName );
            break;
        case adCurrency:
            strDataType = "adCurrency";
			wsprintf(szMemberName , "m_li%s", lpszName);
            strClassAttributes.Format("\tLARGE_INTEGER\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
       case adDBTimeStamp:
       case adDate:
            strDataType = "adDate";
			wsprintf(szMemberName , "m_dt%s", lpszName);
            strClassAttributes.Format("\tDATE\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adDBDate:
            strDataType = "adDBDate";
			wsprintf(szMemberName , "m_dbdt%s", lpszName);
            strClassAttributes.Format("\tDBDATE\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adDBTime:
            strDataType = "adDBTime";
			wsprintf(szMemberName , "m_dbtm%s", lpszName);
            strClassAttributes.Format("\tDBTIME\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
//        case adDBTimeStamp:
//          strDataType = "adDBTimeStamp";
//			wsprintf(szMemberName , "m_dbtm%s", lpszName);
//          strClassAttributes.Format("\tDBTIMESTAMP\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
//            break;
        case adDecimal:
            strDataType = "adDecimal";
 			wsprintf(szMemberName , "m_dec%s", lpszName);
            strClassAttributes.Format("\tDBDECIMAL\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
           break;
        case adDouble:
            strDataType = "adDouble";
			wsprintf(szMemberName , "m_d%s", lpszName);
            strClassAttributes.Format("\tDOUBLE\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adEmpty:
            strDataType = "adEmpty";
            break;
        case adError:
            strDataType = "adError";
			wsprintf(szMemberName , "m_err%s", lpszName);
            strClassAttributes.Format("\tSCODE\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adFileTime:
            strDataType = "adFileTime";
            break;
        case adGUID:
			bExcept = TRUE;
            strDataType = "adGUID";
			wsprintf(szMemberName , "m_sz%s", lpszName);
            strClassAttributes.Format("\tCHAR\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize + 1, lpszName );
            break;
        case adIDispatch:
            strDataType = "adIDispatch";
			wsprintf(szMemberName , "m_Id%s", lpszName);
            strClassAttributes.Format("\tIDispatch * %s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adInteger:
            strDataType = "adInteger";
			wsprintf(szMemberName , "m_l%s", lpszName);
            strClassAttributes.Format("\tLONG\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adIUnknown:
            strDataType = "adIUnknown";
            break;
        case adLongVarBinary:
			bExcept = TRUE;
            strDataType = "adLongVarBinary";
			wsprintf(szMemberName , "m_bt%s", lpszName);
			lDefinedSize = (lDefinedSize <= 4096 * 2) ? lDefinedSize : 4096 * 2;
            strClassAttributes.Format("\tBYTE\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize, lpszName );
            break;
        case adLongVarChar:
			bExcept = TRUE;
            strDataType = "adLongVarChar";
			wsprintf(szMemberName , "m_sz%s", lpszName);
			lDefinedSize = (lDefinedSize <= 4096 * 2) ? lDefinedSize : 4096 * 2;
            strClassAttributes.Format("\tCHAR\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize, lpszName );
            break;
        case adLongVarWChar:
			bExcept = TRUE;
            strDataType = "adLongVarWChar";
			wsprintf(szMemberName , "m_sz%s", lpszName);
			lDefinedSize = (lDefinedSize <= 4096 * 2) ? lDefinedSize : 4096 * 2;
            strClassAttributes.Format("\tCHAR\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize, lpszName );
            break;
        case adNumeric:
            strDataType = "adNumeric";
			wsprintf(szMemberName , "m_num%s", lpszName);
            strClassAttributes.Format("\tDBNUMERIC\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adPropVariant:
            strDataType = "adPropVariant";
            break;
        case adSingle:
            strDataType = "adSingle";
			wsprintf(szMemberName , "m_f%s", lpszName);
            strClassAttributes.Format("\tFLOAT\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adSmallInt:
            strDataType = "adSmallInt";
			wsprintf(szMemberName , "m_s%s", lpszName);
            strClassAttributes.Format("\tSHORT\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adTinyInt:
            strDataType = "adTinyInt";
			wsprintf(szMemberName , "m_c%s", lpszName);
            strClassAttributes.Format("\tsigned char %s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adUnsignedBigInt:
            strDataType = "adUnsignedBigInt"; 
			wsprintf(szMemberName , "m_uli%s", lpszName);
            strClassAttributes.Format("\tULARGE_INTEGER\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adUnsignedInt:
            strDataType = "adUnsignedInt";
			wsprintf(szMemberName , "m_u%s", lpszName);
            strClassAttributes.Format("\tunsigned int\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adUnsignedSmallInt:
            strDataType = "adUnsignedSmallInt";
 			wsprintf(szMemberName , "m_us%s", lpszName);
            strClassAttributes.Format("\tunsigned short\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adUnsignedTinyInt:
            strDataType = "adUnsignedTinyInt";
			wsprintf(szMemberName , "m_bt%s", lpszName);
            strClassAttributes.Format("\tBYTE\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adUserDefined:
            strDataType = "adUserDefined";
            break;
        case adVarBinary:
 			bExcept = TRUE;
            strDataType = "adVarBinary";
			wsprintf(szMemberName , "m_sz%s", lpszName);
			lDefinedSize = (lDefinedSize <= 4096 * 2) ? lDefinedSize : 4096 * 2;
            strClassAttributes.Format("\tBYTE\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize, lpszName );
            break;
        case adVarChar:
			bExcept = TRUE;
            strDataType = "adVarChar";
			wsprintf(szMemberName , "m_sz%s", lpszName);
            strClassAttributes.Format("\tCHAR\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize + 1, lpszName );
            break;
        case adVariant:
            strDataType = "adVariant";
			wsprintf(szMemberName , "m_vt%s", lpszName);
            strClassAttributes.Format("\tVARIANT\t\t\t%s;\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lpszName );
            break;
        case adVarNumeric:
            strDataType = "adVarNumeric";
            break;
        case adVarWChar:
			bExcept = TRUE;
            strDataType = "adVarWChar";
			wsprintf(szMemberName , "m_sz%s", lpszName);
            strClassAttributes.Format("\tCHAR\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize + 1, lpszName );
            break;
        case adWChar:
			bExcept = TRUE;
            strDataType = "adWChar";
			wsprintf(szMemberName , "m_sz%s", lpszName);
            strClassAttributes.Format("\tCHAR\t\t\t%s[%u];\n\tULONG\t\t\tm_ul%sStatus;\n", szMemberName, lDefinedSize + 1, lpszName );
            break;
        default:
            strDataType = "*UNKNOWN*";
            break;
    }

	if(pField->Attributes & adFldFixed && !bExcept)
	{
		strClassMACRO.Format("\tADO_FIXED_LENGTH_ENTRY    (%3d, %s, %s, m_ul%sStatus, %s)\n", 
			nIndex, strDataType, szMemberName, lpszName,
		//	pField->Attributes & adFldUpdatable ? "TRUE" : "FALSE");
			"TRUE");

	}
	else
	{
		strClassMACRO.Format("\tADO_VARIABLE_LENGTH_ENTRY2(%3d, %s, %s, sizeof(%s), m_ul%sStatus, %s)\n", 
			nIndex, strDataType, szMemberName, szMemberName, lpszName,
		//	pField->Attributes & adFldUpdatable ? "TRUE" : "FALSE");
			"TRUE");
	}


}

void CADORsWizardSheet::OnAbout()
{
	CAboutBox dlg;
	dlg.DoModal();
}