// WizardPage1.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "WizardPage1.h"
#include "ADORsWizardSheet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CWizardPage1, CPropertyPage)
IMPLEMENT_DYNCREATE(CWizardPage2, CPropertyPage)


/////////////////////////////////////////////////////////////////////////////
// CWizardPage1 property page

CWizardPage1::CWizardPage1() : CPropertyPage(CWizardPage1::IDD)
{
	//{{AFX_DATA_INIT(CWizardPage1)
	m_strClassName = _T("");
	m_strFileName = _T("");
	m_strDir = _T("");
	//}}AFX_DATA_INIT
}

CWizardPage1::~CWizardPage1()
{
}

void CWizardPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizardPage1)
	DDX_Control(pDX, IDC_EDIT_CLASSFILE, m_editFileName);
	DDX_Text(pDX, IDC_EDIT_CLASSNAME, m_strClassName);
	DDX_Text(pDX, IDC_EDIT_CLASSFILE, m_strFileName);
	DDX_Text(pDX, IDC_EDIT_DIRNAME, m_strDir);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizardPage1, CPropertyPage)
	//{{AFX_MSG_MAP(CWizardPage1)
	ON_EN_CHANGE(IDC_EDIT_CLASSNAME, OnChangeEditClassname)
	ON_BN_CLICKED(IDC_BUTTON_CHANGEFILE, OnButtonChangeDir)
	ON_EN_CHANGE(IDC_EDIT_CLASSFILE, OnChangeEditClassfile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWizardPage2 property page

CWizardPage2::CWizardPage2() : CPropertyPage(CWizardPage2::IDD)
{
	//{{AFX_DATA_INIT(CWizardPage2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CWizardPage2::~CWizardPage2()
{
}

void CWizardPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizardPage2)
	DDX_Control(pDX, IDC_LIST_TABLES, m_listboxTables);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizardPage2, CPropertyPage)
	//{{AFX_MSG_MAP(CWizardPage2)
	ON_LBN_SELCHANGE(IDC_LIST_TABLES, OnSelchangeListTables)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


LRESULT CWizardPage1::OnWizardBack() 
{
	return CPropertyPage::OnWizardBack();
}

LRESULT CWizardPage1::OnWizardNext() 
{
   CADORsWizardSheet* pSheet = (CADORsWizardSheet*) GetParent();	
   UpdateData(TRUE);
   pSheet->m_strClassName = m_strClassName;
   pSheet->m_strFileName  = m_strFileName;
   pSheet->m_strDir		  = m_strDir;
   if(pSheet->GetDBConnection())
	{
		pSheet->SetWizardButtons(PSWIZB_BACK);

		return CPropertyPage::OnWizardNext();
	}
	return -1;
}

void CWizardPage1::OnChangeEditClassfile() 
{
	UpdateData(TRUE);
    CPropertySheet* pSheet = (CPropertySheet*) GetParent();	
	if(!m_strFileName.IsEmpty() && !m_strClassName.IsEmpty())
		pSheet->SetWizardButtons(PSWIZB_NEXT);
	else
		pSheet->SetWizardButtons(0);
	
}


LRESULT CWizardPage2::OnWizardBack() 
{
	CADORsWizardSheet* pSheet = (CADORsWizardSheet*) GetParent();	
	pSheet->CloseDBConnection();
	pSheet->m_strTableName = _T("");

	pSheet->SetWizardButtons(PSWIZB_NEXT);
	return CPropertyPage::OnWizardBack();
}


BOOL CWizardPage2::OnWizardFinish() 
{
	CADORsWizardSheet* pSheet = (CADORsWizardSheet*) GetParent();	
	pSheet->GenerateFile();
	
	return CPropertyPage::OnWizardFinish();
}


void CWizardPage2::OnSelchangeListTables() 
{
	CADORsWizardSheet* pSheet = (CADORsWizardSheet*) GetParent();
	int nSel = m_listboxTables.GetCurSel();
	if(nSel == LB_ERR)
	{
		pSheet->m_strTableName = _T("");
		pSheet->SetWizardButtons(PSWIZB_BACK);
	}
	else
	{
		m_listboxTables.GetText(nSel, pSheet->m_strTableName);
		pSheet->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);
	}

}



BOOL CWizardPage2::OnSetActive() 
{
	CADORsWizardSheet* pSheet = (CADORsWizardSheet*) GetParent();	

	if(!pSheet->FillListOfTables())
	{
		//Go back to Wizard page 1
		pSheet->SetWizardButtons(PSWIZB_NEXT);
		return FALSE;
	}

	return CPropertyPage::OnSetActive();
}


void CWizardPage1::OnChangeEditClassname() 
{
	UpdateData(TRUE);
	if(m_strClassName.IsEmpty())
	{
		m_strFileName.Empty();
	}
	else
	{
		m_strFileName = m_strClassName + _T(".h");
		if(m_strFileName.GetAt(0) == _T('C'))
		{
			m_strFileName.Delete(0);
		}
	}
	UpdateData(FALSE);

    CPropertySheet* pSheet = (CPropertySheet*) GetParent();	
	if(!m_strFileName.IsEmpty() && !m_strClassName.IsEmpty())
		pSheet->SetWizardButtons(PSWIZB_NEXT);
	else
		pSheet->SetWizardButtons(0);


}

void CWizardPage1::OnButtonChangeDir() 
{
  	CADORsWizardSheet* pSheet = (CADORsWizardSheet*) GetParent();	

	LPMALLOC pMalloc;
    /* Gets the Shell's default allocator */
    if (::SHGetMalloc(&pMalloc) == NOERROR)
    {
        BROWSEINFO bi;
        char pszBuffer[MAX_PATH];
        LPITEMIDLIST pidl;
        // Get help on BROWSEINFO struct - it's got all the bit settings.
        bi.hwndOwner = GetSafeHwnd();
        bi.pidlRoot = NULL;
        bi.pszDisplayName = pszBuffer;
        bi.lpszTitle = _T("Select a Starting Directory");
        bi.ulFlags = BIF_RETURNFSANCESTORS | BIF_RETURNONLYFSDIRS;
        bi.lpfn = NULL;
        bi.lParam = 0;
        // This next call issues the dialog box.
        if ((pidl = ::SHBrowseForFolder(&bi)) != NULL)
        {
            if (::SHGetPathFromIDList(pidl, pszBuffer))
            { 
            // At this point pszBuffer contains the selected path */.
                m_strDir = pSheet->m_strDir = pszBuffer;

            }
            // Free the PIDL allocated by SHBrowseForFolder.
            pMalloc->Free(pidl);
        }
        // Release the shell's allocator.
        pMalloc->Release();
    }
	
	UpdateData(FALSE);
}


