// WizardPage1.h : header file
//

#ifndef __WIZARDPAGE1_H__
#define __WIZARDPAGE1_H__

/////////////////////////////////////////////////////////////////////////////
// CWizardPage1 dialog

class CWizardPage1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CWizardPage1)

// Construction
public:
	CWizardPage1();
	~CWizardPage1();

// Dialog Data
	//{{AFX_DATA(CWizardPage1)
	enum { IDD = IDD_WIZPAGE1 };
	CEdit	m_editFileName;
	CString	m_strClassName;
	CString	m_strFileName;
	CString	m_strDir;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizardPage1)
	public:
	virtual LRESULT OnWizardBack();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWizardPage1)
	afx_msg void OnChangeEditClassname();
	afx_msg void OnButtonChangeDir();
	afx_msg void OnChangeEditClassfile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


/////////////////////////////////////////////////////////////////////////////
// CWizardPage2 dialog

class CWizardPage2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CWizardPage2)

// Construction
public:
	CWizardPage2();
	~CWizardPage2();

// Dialog Data
	//{{AFX_DATA(CWizardPage2)
	enum { IDD = IDD_WIZPAGE2 };
	CListBox	m_listboxTables;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizardPage2)
	public:
	virtual LRESULT OnWizardBack();
	virtual BOOL OnSetActive();
	virtual BOOL OnWizardFinish();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWizardPage2)
	afx_msg void OnSelchangeListTables();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


#endif // __WIZARDPAGE1_H__
