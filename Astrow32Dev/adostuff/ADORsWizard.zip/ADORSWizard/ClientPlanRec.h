#ifndef _CCLIENTPLANREC_H_
#define _CCLIENTPLANREC_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// NOTE : In order to use this code against a different version of ADO, the appropriate
// ADO library needs to be used in the #import statement
#import "C:\Program Files\Common Files\System\ADO\msado15.dll" rename_namespace("ADOCG") rename("EOF", "EndOfFile")
using namespace ADOCG;
#include "icrsint.h"

#include "oledb.h"

// ClientPlanRec.h : header file
//

//Note: Remove this #define if you don't want it to be here...
#define DSN_CONNECT_STRING _T(  "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=S:\\tim\\climet.mdb;M"\
"ode=Share Deny None;Extended Properties=\"\";Jet OLEDB:System database=\"\";"\
"Jet OLEDB:Registry Path=\"\";Jet OLEDB:Database Password=\"\";Jet OLEDB:Engi"\
"ne Type=4;Jet OLEDB:Database Locking Mode=0;Jet OLEDB:Global Partial Bulk Op"\
"s=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password=\"\"\
"";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Je"\
"t OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica"\
" Repair=False;Jet OLEDB:SFP=False")

/////////////////////////////////////////////////////////////////////////////
// CClientPlanRec class

class CClientPlanRec : public CADORecordBinding
{
BEGIN_ADO_BINDING(CClientPlanRec)
	ADO_FIXED_LENGTH_ENTRY    (  1, adInteger, m_lClient_id, m_ulClient_idStatus, TRUE)
	ADO_VARIABLE_LENGTH_ENTRY2(  2, adVarWChar, m_szClient_id_name, sizeof(m_szClient_id_name), m_ulClient_id_nameStatus, TRUE)
	ADO_VARIABLE_LENGTH_ENTRY2(  3, adVarWChar, m_szClient_id_desc, sizeof(m_szClient_id_desc), m_ulClient_id_descStatus, TRUE)
END_ADO_BINDING()

//Attributes
public:
	LONG			m_lClient_id;
	ULONG			m_ulClient_idStatus;
	CHAR			m_szClient_id_name[51];
	ULONG			m_ulClient_id_nameStatus;
	CHAR			m_szClient_id_desc[51];
	ULONG			m_ulClient_id_descStatus;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !_CCLIENTPLANREC_H_
