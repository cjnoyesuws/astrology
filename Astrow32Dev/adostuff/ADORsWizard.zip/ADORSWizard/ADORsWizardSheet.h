// ADORsWizardSheet.h : header file
//
// This class defines custom modal property sheet 
// CADORsWizardSheet.
 
#ifndef __ADORSWIZARDSHEET_H__
#define __ADORSWIZARDSHEET_H__

#include "WizardPage1.h"

/////////////////////////////////////////////////////////////////////////////
// CADORsWizardSheet

class CADORsWizardSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CADORsWizardSheet)

// Construction
public:
	CADORsWizardSheet(CWnd* pWndParent = NULL);

// Attributes
public:
	CWizardPage1 m_Page1;
	CWizardPage2 m_Page2;
//Attributes
public:
	BOOL m_bIsConnectionOpen;
	_ConnectionPtr m_pConnection;
	CString m_strTableName;
	CString m_strFileName;
	CString m_strDir;
	CString m_strClassName;
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CADORsWizardSheet)
	public:
	virtual BOOL OnInitDialog();
	protected:
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL GenerateFile();
	void CloseDBConnection();
	BOOL FillListOfTables();
	virtual ~CADORsWizardSheet();
	BOOL GetDBConnection();
	void GenerateComError(_com_error &e);
	void GenerateProviderError(_ConnectionPtr pConnection);
	void BuildClassBindingString(FieldPtr pField, LPCTSTR lpszName, int nIndex, CString& strClassAttributes, CString&  strClassMACRO);
// Generated message map functions
protected:
	//{{AFX_MSG(CADORsWizardSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	afx_msg void OnAbout();
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// __ADORSWIZARDSHEET_H__
